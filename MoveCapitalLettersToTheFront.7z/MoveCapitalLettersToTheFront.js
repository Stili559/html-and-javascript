function MoveCapitalLettersToTheFront(input){

    let lowerCase = [];
    let upperCase = [];

    for(let i = 0; i < input.length; i++)
    {     
        if(input[i] >= 'a' && 'z' <= input[i])
        {
            upperCase += input[i];
        }
        else
        {
            lowerCase += input[i];  
        }
        completeWord = upperCase + lowerCase;
    }
    console.log(completeWord);
}

MoveCapitalLettersToTheFront('hApPy');