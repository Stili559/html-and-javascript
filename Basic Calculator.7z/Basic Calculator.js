function basicCalculator (a, b, c) {
    let firstNum = 0;
  
      switch(c) {

        case '+':
            firstNum = a + b
          break;
  
        case '-':
            firstNum = a - b
          break;

        case '*':
            firstNum = a * b
          break;
  
       case '/': 
          if (b === 0 || a === 0) 
          {
            console.log("Can't divide by 0!")
          } 
          else 
          {
            firstNum = a / b
          }
          break;
      }
      return firstNum;
  }
  console.log(basicCalculator(2,2,'+'));

  