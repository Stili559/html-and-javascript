function GetTheAreaOfACountry(country, area) {
    let math = area / 148940000 * 100
    console.log(country + " is "  + math.toFixed(2) + "% of the total world's landmass");
}

GetTheAreaOfACountry('Russia', 17098242);
GetTheAreaOfACountry('USA', 9372610);
GetTheAreaOfACountry('Iran', 1648195);
