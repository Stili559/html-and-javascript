function FoldingAPieceOfPaper(folding) {
    let math = 0.0005 * Math.pow(2, folding);
    console.log(math + 'm');
}

FoldingAPieceOfPaper(1);
FoldingAPieceOfPaper(4);
FoldingAPieceOfPaper(21);
