function FindTheSecondLargestNumber(numbers) {
    let a = []
    let b = []
    let c = (b, a)[3]
    let sort = (numbers.sort((c))[3])
        console.log(sort);
    }
    
    FindTheSecondLargestNumber([10, 40, 30, 20, 50]) 
    FindTheSecondLargestNumber([25, 143, 89, 13, 105])
    FindTheSecondLargestNumber([54, 23, 11, 17, 10]) 
    